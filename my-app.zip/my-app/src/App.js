import React from 'react';

import './Features.css'
import Features from './Features';




function App() {
  return (
   
    <div className='App'>
      <Features/>
     
     
     </div>
      
  
  );
}

export default App;
